int counter = 10;
counter++;
Console.WriteLine(counter<5);
